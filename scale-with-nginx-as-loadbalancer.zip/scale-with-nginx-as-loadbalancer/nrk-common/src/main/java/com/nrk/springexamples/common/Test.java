package com.nrk.springexamples.common;
import java.util.Arrays;
import java.util.List;



public class Test {

	public static void main(String[] args) throws Exception {
		List<String> list = Arrays.asList();
		System.out.println(list.get(0));
	}
}
